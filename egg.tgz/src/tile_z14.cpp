// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Pack zoom-14 tiles\n", stdout);
  return lionss_run_workload("tile_z14");
}
