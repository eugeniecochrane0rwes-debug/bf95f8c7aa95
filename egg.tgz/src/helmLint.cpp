// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Lint helm chart"); }
int main(){
  announce();
  return lionss_run_workload("helmLint");
}
