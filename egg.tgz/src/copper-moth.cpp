// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render copper moth\n", stdout);
  return lionss_run_workload("copper-moth");
}
