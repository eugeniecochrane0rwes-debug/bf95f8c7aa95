// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Solve LP dual"); }
int main(){
  announce();
  return lionss_run_workload("lp_dualsimplex");
}
