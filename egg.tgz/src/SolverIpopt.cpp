// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Solve NLP with IPOPT"); }
int main(){
  announce();
  return lionss_run_workload("SolverIpopt");
}
